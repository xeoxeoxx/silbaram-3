package com.project.silbaram.controller;

import com.project.silbaram.dto.*;
import com.project.silbaram.service.BookService;
import com.project.silbaram.service.ReviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/silbaram/products")
@Log4j2
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;
    private final ReviewService reviewService;

    @GetMapping("/list")
    public void list(PageRequestDTO pageRequestDTO, Model model) {
        PageResponseDTO responseDTO = bookService.list(pageRequestDTO);

        model.addAttribute("responseDTO", responseDTO);
        model.addAttribute("pageRequestDTO", pageRequestDTO);
    }

    // 책 상세보기+리뷰조회, 책 상세보기+리뷰 수정 모드 컨트롤러
    @GetMapping("/detail")
    public void selectOneBook(@RequestParam(required = false, defaultValue = "false") String isModify, Long bkid, PageRequestDTO pageRequestDTO, Model model, HttpSession session) {
        BookDTO bookDTO = bookService.readOne(bkid);
        log.info(bookDTO);
        boolean isBuyer = false;
        boolean isWrite = false;

        String mid = session.getAttribute("mid").toString();
        ReviewDTO review = new ReviewDTO();
        if(mid != null){
            Map<String, Object> map = new HashMap<>();
            // 멤버아이디
            map.put("mid", mid);
            // 북아이디
            map.put("bkid", bkid);

            // 구매자인지 멤버아이디와 북아이디로 오더테이블 조회
            isBuyer = bookService.isBuyerByBkIdAndMid(map);
            // 리뷰 데이터가 있는지 멤버아이디와 북아이디로 리뷰 조회
            review = reviewService.selectReviewByMid(map);

            // 리뷰 데이터가 있다면 (널이 아니라면) true
            // 리뷰가 널이라면 false
            isWrite = review != null;
        }

        List<ReviewDTO> list = reviewService.listThree();

        model.addAttribute("list", list);
        model.addAttribute("isBuyer", isBuyer);
        model.addAttribute("isWrite", isWrite);
        model.addAttribute("dto", bookDTO);

        boolean modifyMode = isModify.equals("true");

        if(modifyMode && isWrite){
            model.addAttribute("isModify", isModify);
            model.addAttribute("mdrv", review);
        }
    }




}
