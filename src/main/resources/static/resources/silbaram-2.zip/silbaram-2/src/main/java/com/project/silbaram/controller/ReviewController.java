package com.project.silbaram.controller;

import com.project.silbaram.dto.PageRequestDTO;
import com.project.silbaram.dto.PageResponseDTO;
import com.project.silbaram.dto.ReviewDTO;
import com.project.silbaram.service.ReviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("/silbaram/review")
@Log4j2
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @GetMapping({"/list", "/total"})
    public void list(PageRequestDTO pageRequestDTO, Model model) {
        PageResponseDTO responseDTO = reviewService.list(pageRequestDTO);
        log.info(responseDTO);
        model.addAttribute("responseDTO", responseDTO);
    }

    //@RequestMapping(value = "/register", method = RequestMethod.GET)
    @GetMapping("/register")
    public void registerGET() {
        log.info("GET review register...");
    }

    @PostMapping("/register")
    public String registerPOST(@Valid ReviewDTO reviewDTO, BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        log.info("POST review register...");

        if (bindingResult.hasErrors()) {
            log.info("review register has error...");
            redirectAttributes.addFlashAttribute("errors", bindingResult.getAllErrors());
            return "redirect:/silbaram/products/detail?bkid="+reviewDTO.getBkid();
        }
        log.info("REVIEW", reviewDTO);
        reviewService.register(reviewDTO);
        return "redirect:/silbaram/products/detail?bkid="+reviewDTO.getBkid();
    }

    @GetMapping( "/modify")
    public void read(Long rid, PageRequestDTO pageRequestDTO, Model model) {
        ReviewDTO reviewDTO = reviewService.readOne(rid);
        log.info("review {}", reviewDTO);

        model.addAttribute("dto", reviewDTO);
    }



    @PostMapping("/modify")
    public String modify(PageRequestDTO pageRequestDTO, @Valid ReviewDTO reviewDTO, BindingResult bindingResult, RedirectAttributes redirectAttributes) { //유효성 검가 결과 에러가 있으면 수정페이지로 돌아감
        log.info("----------modify--------");
        if (bindingResult.hasErrors()) {
            log.info("modify has error...");
            redirectAttributes.addFlashAttribute("errors", bindingResult.getAllErrors());
            redirectAttributes.addAttribute("rid", reviewDTO.getRid());
            return "redirect:/silbaram/review/modify";
        }
        log.info(reviewDTO);
        reviewService.modify(reviewDTO);

       // redirectAttributes.addAttribute("rid", reviewDTO.getRid());

        return "redirect:/silbaram/products/detail?bkid="+reviewDTO.getBkid();
       // return "redirect:/silbaram/products/list";
    }

    @PostMapping("/remove")
    public String remove(Long bkid, Long rid, PageRequestDTO pageRequestDTO, RedirectAttributes redirectAttributes) {
        log.info("-------------remove------------");
        log.info("rid: " + rid);
        log.info("bkid: " + bkid);
        log.info("rid: " + pageRequestDTO);

        reviewService.remove(rid);

        return "redirect:/silbaram/products/detail?bkid="+ bkid;
    }

}
