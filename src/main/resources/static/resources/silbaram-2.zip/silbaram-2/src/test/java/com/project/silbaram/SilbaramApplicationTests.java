package com.project.silbaram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SilbaramApplicationTests {

    @Test
    void contextLoads() {
    }

}
