package com.project.silbaram.dao;


public interface TimeMapper {
    String getNow();

}