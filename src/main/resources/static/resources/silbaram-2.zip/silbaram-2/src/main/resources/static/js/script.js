$('#category_all_btn').click(function(){
    $('#nav').slideToggle();
})

$('#nav ul li').click(function(){
    $('#nav ul li ul').slideUp();
    $(this).children("ul").slideToggle();
})